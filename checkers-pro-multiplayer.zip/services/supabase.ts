
import { createClient } from 'https://esm.sh/@supabase/supabase-js@^2.45.0';

const supabaseUrl = 'https://otavsdqcjhstflmmjagr.supabase.co';
const supabaseKey = 'sb_publishable_5z5Tnlyulln6xv4rQuan_w_TGA-rdxQ';

export const supabase = createClient(supabaseUrl, supabaseKey);
