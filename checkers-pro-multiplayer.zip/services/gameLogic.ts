
import { Piece, PieceColor, PieceType, Move } from '../types';
import { BOARD_SIZE } from '../constants';

export class GameEngine {
  static getValidMoves(pieces: Piece[], turn: PieceColor): Move[] {
    const playerPieces = pieces.filter(p => p.color === turn);
    const jumpMoves: Move[] = [];

    // 1. Procurar por capturas (Obrigatórias por lei)
    for (const piece of playerPieces) {
      this.findJumpPaths(piece, pieces, [], jumpMoves, piece.row, piece.col);
    }

    if (jumpMoves.length > 0) {
      // Lei da Maioria: Dama vale 2, Peão vale 1
      let maxScore = 0;
      for (const move of jumpMoves) {
        const score = this.calculateMoveScore(move);
        if (score > maxScore) maxScore = score;
      }
      return jumpMoves.filter(m => this.calculateMoveScore(m) === maxScore);
    }

    // 2. Movimentos regulares (apenas se não houver capturas)
    const regularMoves: Move[] = [];
    for (const piece of playerPieces) {
      this.getRegularMoves(piece, pieces, regularMoves);
    }

    return regularMoves;
  }

  private static calculateMoveScore(move: Move): number {
    if (!move.captures) return 0;
    return move.captures.reduce((acc, p) => acc + (p.type === PieceType.KING ? 2 : 1), 0);
  }

  private static getRegularMoves(piece: Piece, pieces: Piece[], result: Move[]) {
    const directions = piece.type === PieceType.KING 
      ? [[1, 1], [1, -1], [-1, 1], [-1, -1]]
      : (piece.color === PieceColor.WHITE ? [[-1, 1], [-1, -1]] : [[1, 1], [1, -1]]);

    for (const [dr, dc] of directions) {
      let nr = piece.row + dr;
      let nc = piece.col + dc;

      if (piece.type === PieceType.KING) {
        while (this.isWithinBounds(nr, nc) && !this.getPieceAt(nr, nc, pieces)) {
          result.push({ fromRow: piece.row, fromCol: piece.col, toRow: nr, toCol: nc });
          nr += dr;
          nc += dc;
        }
      } else {
        if (this.isWithinBounds(nr, nc) && !this.getPieceAt(nr, nc, pieces)) {
          result.push({ fromRow: piece.row, fromCol: piece.col, toRow: nr, toCol: nc });
        }
      }
    }
  }

  private static findJumpPaths(
    currentPiece: Piece, 
    allPieces: Piece[], 
    capturedSoFar: Piece[], 
    allPaths: Move[],
    startRow: number,
    startCol: number
  ) {
    const directions = [[1, 1], [1, -1], [-1, 1], [-1, -1]];
    let canJumpMore = false;

    for (const [dr, dc] of directions) {
      if (currentPiece.type === PieceType.KING) {
        let nr = currentPiece.row + dr;
        let nc = currentPiece.col + dc;
        let enemy: Piece | null = null;

        while (this.isWithinBounds(nr, nc)) {
          const p = this.getPieceAt(nr, nc, allPieces);
          if (p) {
            if (p.color === currentPiece.color || capturedSoFar.some(c => c.id === p.id)) break;
            if (enemy) break;
            enemy = p;
          } else if (enemy) {
            canJumpMore = true;
            const newCaptured = [...capturedSoFar, enemy];
            const nextPos = { ...currentPiece, row: nr, col: nc };
            const countBefore = allPaths.length;
            
            this.findJumpPaths(nextPos, allPieces, newCaptured, allPaths, startRow, startCol);
            
            if (allPaths.length === countBefore) {
              allPaths.push({ fromRow: startRow, fromCol: startCol, toRow: nr, toCol: nc, captures: newCaptured });
            }
          }
          nr += dr;
          nc += dc;
        }
      } else {
        const midR = currentPiece.row + dr;
        const midC = currentPiece.col + dc;
        const endR = currentPiece.row + 2 * dr;
        const endC = currentPiece.col + 2 * dc;

        if (this.isWithinBounds(endR, endC)) {
          const midP = this.getPieceAt(midR, midC, allPieces);
          const endP = this.getPieceAt(endR, endC, allPieces);

          if (midP && midP.color !== currentPiece.color && !endP && !capturedSoFar.some(c => c.id === midP.id)) {
            canJumpMore = true;
            const newCaptured = [...capturedSoFar, midP];
            const nextPos = { ...currentPiece, row: endR, col: endC };
            const countBefore = allPaths.length;

            this.findJumpPaths(nextPos, allPieces, newCaptured, allPaths, startRow, startCol);

            if (allPaths.length === countBefore) {
              allPaths.push({ fromRow: startRow, fromCol: startCol, toRow: endR, toCol: endC, captures: newCaptured });
            }
          }
        }
      }
    }
  }

  static isWithinBounds = (r: number, c: number) => r >= 0 && r < BOARD_SIZE && c >= 0 && c < BOARD_SIZE;
  static getPieceAt = (r: number, c: number, pieces: Piece[]) => pieces.find(p => p.row === r && p.col === c);

  static performMove(pieces: Piece[], move: Move): { newPieces: Piece[], promoted: boolean } {
    const piece = pieces.find(p => p.row === move.fromRow && p.col === move.fromCol);
    if (!piece) return { newPieces: pieces, promoted: false };

    let newPieces = pieces.filter(p => p.id !== piece.id);
    const updatedPiece = { ...piece, row: move.toRow, col: move.toCol };

    if (move.captures) {
      const captureIds = move.captures.map(c => c.id);
      newPieces = newPieces.filter(p => !captureIds.includes(p.id));
    }

    let promoted = false;
    // Promoção ocorre apenas se terminar a jogada na última casa
    if (updatedPiece.type === PieceType.MAN) {
      const isAtEnd = (updatedPiece.color === PieceColor.WHITE && updatedPiece.row === 0) || 
                      (updatedPiece.color === PieceColor.RED && updatedPiece.row === BOARD_SIZE - 1);
      if (isAtEnd) {
        updatedPiece.type = PieceType.KING;
        promoted = true;
      }
    }

    newPieces.push(updatedPiece);
    return { newPieces, promoted };
  }

  static checkGameOver(pieces: Piece[], turn: PieceColor): { finished: boolean, winner?: PieceColor } {
    if (this.getValidMoves(pieces, turn).length === 0) {
      return { finished: true, winner: turn === PieceColor.WHITE ? PieceColor.RED : PieceColor.WHITE };
    }
    return { finished: false };
  }
}
