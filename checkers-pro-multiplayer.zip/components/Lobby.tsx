
import React, { useState } from 'react';
import { Room, RoomType, BoardTheme, GameStatus } from '../types';
import { Plus, Users, Eye, Globe, Lock, Shield, Settings2 } from 'lucide-react';

interface LobbyProps {
  rooms: Room[];
  onJoinRoom: (room: Room) => void;
  onCreateRoom: (params: any) => void;
}

const Lobby: React.FC<LobbyProps> = ({ rooms, onJoinRoom, onCreateRoom }) => {
  const [isCreateModalOpen, setCreateModalOpen] = useState(false);
  const [newRoomName, setNewRoomName] = useState('');
  const [newRoomType, setNewRoomType] = useState<RoomType>(RoomType.PUBLIC);
  const [newTime, setNewTime] = useState(5);
  const [newIncrement, setNewIncrement] = useState(3);
  const [newTheme, setNewTheme] = useState<BoardTheme>(BoardTheme.GREEN);

  const handleCreate = () => {
    onCreateRoom({
      name: newRoomName || 'Sala de Damas',
      type: newRoomType,
      timeLimit: newTime,
      increment: newIncrement,
      theme: newTheme
    });
    setCreateModalOpen(false);
  };

  return (
    <div className="p-6 pb-24 space-y-6 overflow-y-auto h-full">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-black neon-glow tracking-tighter">ARENA PRO</h1>
          <p className="text-gray-400 text-sm">Damas Internacionais 8x8</p>
        </div>
        <button 
          onClick={() => setCreateModalOpen(true)}
          className="flex items-center space-x-2 bg-[#39ff14] text-black px-4 py-3 rounded-xl font-bold hover:brightness-110 transition-all shadow-[0_0_20px_rgba(57,255,20,0.4)]"
        >
          <Plus className="w-6 h-6" />
          <span>Criar Sala</span>
        </button>
      </div>

      <div className="space-y-4">
        <h2 className="text-lg font-bold flex items-center space-x-2">
          <Globe className="w-5 h-5 text-[#39ff14]" />
          <span>Salas Públicas</span>
        </h2>
        {rooms.length === 0 ? (
          <div className="text-center py-10 bg-[#0d0d0d] rounded-2xl border border-dashed border-gray-800">
            <p className="text-gray-500">Nenhuma sala disponível. Que tal criar uma?</p>
          </div>
        ) : (
          <div className="grid gap-4">
            {rooms.map((room) => (
              <div 
                key={room.id}
                onClick={() => onJoinRoom(room)}
                className="bg-[#0d0d0d] border border-white/5 rounded-2xl p-4 flex items-center justify-between hover:border-[#39ff14]/30 cursor-pointer transition-all active:scale-[0.98]"
              >
                <div className="flex items-center space-x-4">
                  <div className={`p-3 rounded-xl ${room.status === GameStatus.PLAYING ? 'bg-red-500/10 text-red-500' : 'bg-[#39ff14]/10 text-[#39ff14]'}`}>
                    {room.type === RoomType.PUBLIC ? <Globe className="w-6 h-6" /> : <Lock className="w-6 h-6" />}
                  </div>
                  <div>
                    <div className="font-bold">{room.name}</div>
                    <div className="flex items-center space-x-3 text-xs text-gray-400 mt-1">
                      <span className="flex items-center space-x-1"><Users className="w-3 h-3" /> <span>{room.players.length}/2</span></span>
                      <span className="flex items-center space-x-1"><Eye className="w-3 h-3" /> <span>{room.spectators}</span></span>
                      <span className="text-[#39ff14]">{room.timeLimit}m + {room.increment}s</span>
                    </div>
                  </div>
                </div>
                <div className="text-right">
                   <div className={`text-[10px] px-2 py-1 rounded-full border ${
                     room.status === GameStatus.WAITING ? 'border-[#39ff14] text-[#39ff14]' : 
                     room.status === GameStatus.PLAYING ? 'border-orange-500 text-orange-500' : 'border-gray-500 text-gray-500'
                   }`}>
                     {room.status === GameStatus.WAITING ? 'ABERTA' : room.status === GameStatus.PLAYING ? 'EM JOGO' : 'ENCERRADA'}
                   </div>
                   {room.players.length === 2 && (
                     <div className="text-[10px] text-gray-500 mt-2">Assistir como espectador</div>
                   )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Create Room Modal */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/80 backdrop-blur-md">
          <div className="bg-[#0a0a0a] w-full max-w-lg rounded-t-[2.5rem] sm:rounded-3xl border-t sm:border border-white/10 p-8 space-y-6">
            <div className="flex justify-between items-center">
              <h3 className="text-2xl font-black">CONFIGURAR SALA</h3>
              <button onClick={() => setCreateModalOpen(false)} className="text-gray-500 hover:text-white transition-colors">
                 <XCircle className="w-8 h-8" />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="text-xs font-bold text-gray-500 uppercase tracking-widest block mb-2">Nome da Sala</label>
                <input 
                  type="text" 
                  value={newRoomName}
                  onChange={(e) => setNewRoomName(e.target.value)}
                  placeholder="Ex: Arena Master" 
                  className="w-full bg-white/5 border border-white/10 rounded-xl p-4 focus:outline-none focus:border-[#39ff14] transition-all"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                   <label className="text-xs font-bold text-gray-500 uppercase tracking-widest block mb-2">Tipo</label>
                   <select 
                     value={newRoomType}
                     onChange={(e) => setNewRoomType(e.target.value as RoomType)}
                     className="w-full bg-white/5 border border-white/10 rounded-xl p-4 focus:outline-none"
                    >
                     <option value={RoomType.PUBLIC}>Pública</option>
                     <option value={RoomType.PRIVATE}>Privada</option>
                   </select>
                </div>
                <div>
                   <label className="text-xs font-bold text-gray-500 uppercase tracking-widest block mb-2">Tema</label>
                   <select 
                     value={newTheme}
                     onChange={(e) => setNewTheme(e.target.value as BoardTheme)}
                     className="w-full bg-white/5 border border-white/10 rounded-xl p-4 focus:outline-none"
                    >
                     <option value={BoardTheme.GREEN}>Verde Tradicional</option>
                     <option value={BoardTheme.DARK}>Moderno Escuro</option>
                     <option value={BoardTheme.WOOD}>Madeira Clássica</option>
                     <option value={BoardTheme.MINIMAL}>Minimalista Premium</option>
                   </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                   <label className="text-xs font-bold text-gray-500 uppercase tracking-widest block mb-2">Tempo (min)</label>
                   <div className="flex items-center space-x-2">
                     <input 
                      type="range" min="1" max="15" step="1" 
                      value={newTime} onChange={(e) => setNewTime(Number(e.target.value))}
                      className="flex-1 accent-[#39ff14]" 
                     />
                     <span className="w-8 text-center font-bold text-[#39ff14]">{newTime}</span>
                   </div>
                </div>
                <div>
                   <label className="text-xs font-bold text-gray-500 uppercase tracking-widest block mb-2">Inc. (seg)</label>
                   <div className="flex items-center space-x-2">
                     <input 
                      type="range" min="0" max="10" step="1" 
                      value={newIncrement} onChange={(e) => setNewIncrement(Number(e.target.value))}
                      className="flex-1 accent-[#39ff14]" 
                     />
                     <span className="w-8 text-center font-bold text-[#39ff14]">{newIncrement}</span>
                   </div>
                </div>
              </div>
            </div>

            <button 
              onClick={handleCreate}
              className="w-full bg-[#39ff14] text-black py-5 rounded-2xl font-black text-xl hover:brightness-110 active:scale-[0.98] transition-all shadow-[0_10px_30px_rgba(57,255,20,0.3)]"
            >
              CRIAR E ENTRAR
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

const XCircle = ({ className }: { className: string }) => (
  <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>
);

export default Lobby;
