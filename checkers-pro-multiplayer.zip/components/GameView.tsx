
import React, { useState, useEffect, useMemo, useRef } from 'react';
import { Piece, PieceColor, PieceType, Move, Room, GameStatus } from '../types';
import { GameEngine } from '../services/gameLogic';
import { THEME_COLORS, BOARD_SIZE } from '../constants';
import { supabase } from '../services/supabase';
import { MoreVertical, MessageCircle, Flag, RotateCcw, Trophy, Users } from 'lucide-react';

interface GameViewProps {
  room: Room;
  currentUser: any;
  onExit: () => void;
  onRestart: () => void;
}

const GameView: React.FC<GameViewProps> = ({ room, currentUser, onExit, onRestart }) => {
  const [pieces, setPieces] = useState<Piece[]>([]);
  const [turn, setTurn] = useState<PieceColor>(PieceColor.WHITE);
  const [selectedPieceId, setSelectedPieceId] = useState<string | null>(null);
  const [timers, setTimers] = useState<{ [key: string]: number }>({});
  const [gameOver, setGameOver] = useState<{ finished: boolean, winner?: PieceColor }>({ finished: false });
  const channelRef = useRef<any>(null);

  useEffect(() => {
    initBoard();
    setupRealtime();
    return () => { channelRef.current?.unsubscribe(); };
  }, [room.id]);

  const setupRealtime = () => {
    const channelId = `game_${room.id}`;
    channelRef.current = supabase.channel(channelId)
      .on('broadcast', { event: 'move' }, ({ payload }) => {
        applyMoveLocally(payload.move, payload.nextTurn);
      })
      .on('presence', { event: 'sync' }, () => {
        // Lógica de presença para detectar offline/online
      })
      .subscribe();
  };

  const initBoard = () => {
    const initial: Piece[] = [];
    let id = 0;
    for (let r = 0; r < BOARD_SIZE; r++) {
      for (let c = 0; c < BOARD_SIZE; c++) {
        if ((r + c) % 2 === 0) {
          if (r < 3) initial.push({ id: `p-${id++}`, color: PieceColor.RED, type: PieceType.MAN, row: r, col: c });
          else if (r > 4) initial.push({ id: `p-${id++}`, color: PieceColor.WHITE, type: PieceType.MAN, row: r, col: c });
        }
      }
    }
    setPieces(initial);
  };

  const allPossibleMoves = useMemo(() => GameEngine.getValidMoves(pieces, turn), [pieces, turn]);

  const currentPieceValidMoves = useMemo(() => {
    if (!selectedPieceId) return [];
    const p = pieces.find(x => x.id === selectedPieceId);
    return allPossibleMoves.filter(m => m.fromRow === p?.row && m.fromCol === p?.col);
  }, [allPossibleMoves, selectedPieceId, pieces]);

  const applyMoveLocally = (move: Move, nextTurn: PieceColor) => {
    const { newPieces } = GameEngine.performMove(pieces, move);
    setPieces(newPieces);
    setTurn(nextTurn);
    const result = GameEngine.checkGameOver(newPieces, nextTurn);
    if (result.finished) setGameOver(result);
  };

  const handleCellClick = (r: number, c: number) => {
    if (gameOver.finished) return;
    const piece = GameEngine.getPieceAt(r, c, pieces);

    if (piece && piece.color === turn) {
      setSelectedPieceId(piece.id);
      return;
    }

    if (selectedPieceId) {
      const move = currentPieceValidMoves.find(m => m.toRow === r && m.toCol === c);
      if (move) {
        const nextTurn = turn === PieceColor.WHITE ? PieceColor.RED : PieceColor.WHITE;
        
        // Zero Delay: Aplica localmente antes do servidor
        applyMoveLocally(move, nextTurn);
        setSelectedPieceId(null);

        // Broadcast para o oponente (Rápido)
        channelRef.current.send({
          type: 'broadcast',
          event: 'move',
          payload: { move, nextTurn }
        });

        // Persistência no DB (Fundo)
        supabase.from('games').upsert({ room_id: room.id, board_state: pieces, turn: nextTurn });
      } else {
        setSelectedPieceId(null);
      }
    }
  };

  const themeColors = THEME_COLORS[room.theme || 'GREEN'];

  return (
    <div className="flex flex-col h-full bg-[#050505] text-white select-none overflow-hidden">
      {/* HUD Superior */}
      <div className="p-4 bg-[#0a0a0a] border-b border-white/5 flex justify-between items-center">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-full bg-red-600/20 border border-red-500/50 flex items-center justify-center">
            <Users className="w-5 h-5 text-red-500" />
          </div>
          <div>
            <div className="text-xs text-gray-500 font-bold uppercase tracking-widest">Oponente</div>
            <div className="font-black text-sm uppercase">Pro_Rival</div>
          </div>
        </div>
        <div className="px-5 py-2 bg-black/40 rounded-xl font-mono text-2xl text-[#39ff14] border border-[#39ff14]/20 shadow-[0_0_15px_rgba(57,255,20,0.1)]">
          04:52
        </div>
      </div>

      {/* Tabuleiro */}
      <div className="flex-1 flex items-center justify-center p-4">
        <div className="w-full max-w-[480px] aspect-square bg-black p-1.5 rounded-lg shadow-[0_30px_70px_rgba(0,0,0,0.9)] border border-white/5 relative">
          <div className="grid grid-cols-8 grid-rows-8 w-full h-full relative overflow-hidden rounded-sm">
            {Array.from({ length: 64 }).map((_, i) => {
              const r = Math.floor(i / 8);
              const c = i % 8;
              const isDark = (r + c) % 2 === 0;
              const piece = GameEngine.getPieceAt(r, c, pieces);
              const isSelected = selectedPieceId === piece?.id;
              const isValidDest = currentPieceValidMoves.some(m => m.toRow === r && m.toCol === c);

              return (
                <div
                  key={`${r}-${c}`}
                  onClick={() => handleCellClick(r, c)}
                  className={`relative flex items-center justify-center ${
                    isDark ? themeColors.dark : themeColors.light
                  } transition-colors duration-300`}
                >
                  {isValidDest && <div className="absolute w-3 h-3 bg-[#39ff14]/60 rounded-full animate-ping" />}
                  {piece && (
                    <div
                      className={`
                        w-[84%] h-[84%] rounded-full transition-all duration-200 z-10
                        flex items-center justify-center border-b-[6px] active:scale-90
                        ${piece.color === PieceColor.WHITE ? 'bg-zinc-200 border-zinc-400' : 'bg-red-600 border-red-900'}
                        ${isSelected ? 'scale-110 -translate-y-1.5 ring-4 ring-[#39ff14] shadow-[0_15px_30px_rgba(57,255,20,0.4)]' : ''}
                      `}
                    >
                      {piece.type === PieceType.KING && (
                        <div className="w-[60%] h-[60%] rounded-full border-2 border-yellow-400/50 flex items-center justify-center">
                          <Trophy className="w-4 h-4 text-yellow-400 drop-shadow-md" />
                        </div>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* HUD Inferior */}
      <div className="p-4 bg-[#0a0a0a] border-t border-white/5 space-y-4 pb-10">
        <div className="flex justify-between items-center">
          <div className="flex items-center space-x-3">
             <img src={currentUser?.avatar} className="w-12 h-12 rounded-full border-2 border-[#39ff14]" />
             <div>
                <div className="text-xs text-gray-500 font-bold uppercase tracking-widest">Você</div>
                <div className="font-black text-sm uppercase">{currentUser?.name}</div>
             </div>
          </div>
          <div className={`px-5 py-2 rounded-xl font-mono text-2xl border ${turn === currentUser?.color ? 'text-[#39ff14] border-[#39ff14]/20 animate-pulse' : 'text-gray-600 border-white/5'}`}>
            05:00
          </div>
        </div>
        
        <div className="grid grid-cols-2 gap-3">
          <button className="bg-white/5 py-4 rounded-2xl font-bold flex items-center justify-center space-x-2 border border-white/5 hover:bg-white/10 transition-all">
            <RotateCcw className="w-4 h-4" /> <span>Empate</span>
          </button>
          <button onClick={onExit} className="bg-red-600/10 text-red-500 py-4 rounded-2xl font-bold flex items-center justify-center space-x-2 border border-red-500/20 hover:bg-red-600/20 transition-all">
            <Flag className="w-4 h-4" /> <span>Desistir</span>
          </button>
        </div>
      </div>

      {/* Modal Game Over */}
      {gameOver.finished && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-black/90 backdrop-blur-md animate-in fade-in duration-500">
           <div className="bg-[#0d0d0d] w-full max-w-sm rounded-[3rem] border border-white/10 p-12 text-center space-y-10 shadow-[0_0_100px_rgba(57,255,20,0.15)]">
              <div className="space-y-6">
                 <div className="w-24 h-24 bg-[#39ff14]/10 rounded-full flex items-center justify-center mx-auto shadow-[0_0_40px_rgba(57,255,20,0.2)]">
                    <Trophy className="w-12 h-12 text-[#39ff14]" />
                 </div>
                 <h2 className="text-5xl font-black italic uppercase tracking-tighter neon-glow">Vitória</h2>
                 <p className="text-gray-400 font-medium">Você subiu +24 pontos de rating!</p>
              </div>
              <button onClick={() => window.location.reload()} className="w-full bg-[#39ff14] text-black py-5 rounded-2xl font-black text-xl shadow-[0_15px_40px_rgba(57,255,20,0.4)] hover:scale-105 transition-all">NOVA PARTIDA</button>
           </div>
        </div>
      )}
    </div>
  );
};

export default GameView;
